
import os
import subprocess
import sys

def main():
    print("🔮 UGCLAWS USERBOT Lite 🔮")
    print("1. Запустить бота")
    print("2. Зарегистрировать новый аккаунт")
    print("3. Выход")
    
    choice = input("Выберите опцию (1-3): ")
    
    if choice == "1":
        # Запуск основного бота
        print("Запуск UserBot...")
        try:
            subprocess.run(["python", "q/bot.py"])
        except KeyboardInterrupt:
            print("\nБот остановлен.")
        except Exception as e:
            print(f"Ошибка при запуске бота: {e}")
    
    elif choice == "2":
        # Запуск регистрационного бота
        print("Запуск бота регистрации...")
        try:
            subprocess.run(["python", "q/register_bot.py"])
        except KeyboardInterrupt:
            print("\nБот регистрации остановлен.")
        except Exception as e:
            print(f"Ошибка при запуске бота регистрации: {e}")
    
    elif choice == "3":
        print("До свидания!")
        sys.exit(0)
    
    else:
        print("Неверный выбор. Пожалуйста, выберите 1, 2 или 3.")

if __name__ == "__main__":
    main()
