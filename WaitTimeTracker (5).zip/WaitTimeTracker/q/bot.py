import json
from telethon import TelegramClient, events
import asyncio
import random
import aiohttp
import logging
import pytz
from datetime import datetime
import os
import time
from telethon.tl.functions.account import UpdateProfileRequest

# Конфигурация
prefixes = ['.', '/', '!', '-']
logger = logging.getLogger(__name__)

SECRET_CODE = "unblockcmd"
unlocked_commands = {}
config_file = "config.json"

def load_config():
    if os.path.exists(config_file):
        with open(config_file, 'r') as f:
            return json.load(f)
    return {}

def save_config(config):
    with open(config_file, 'w') as f:
        json.dump(config, f)

config = load_config()

if "api_id" not in config or "api_hash" not in config:
    api_id = input("Введите api_id: ")
    api_hash = input("Введите api_hash: ")
    config["api_id"] = api_id
    config["api_hash"] = api_hash
    save_config(config)
else:
    api_id = config["api_id"]
    api_hash = config["api_hash"]

# Настройка клиента с дополнительными параметрами для предотвращения кика
client = TelegramClient(
    'session_name', 
    int(api_id), 
    api_hash,
    device_model="Samsung Galaxy S21",  # Используем распространенное устройство
    system_version="Android 12",  # Обычная ОС для телефона
    app_version="8.4.4",  # Стабильная версия официального приложения
    lang_code="ru",  # Язык, используемый в клиенте
    system_lang_code="ru",  # Язык ОС
    connection_retries=10,  # Количество попыток подключения
    auto_reconnect=True,  # Автоматическое переподключение
    flood_sleep_threshold=120  # Увеличенный порог для избежания флуд-контроля
)

# Команда для лоли хентая
@client.on(events.NewMessage(pattern=f'[{"".join(prefixes)}]loli'))
async def lolicmd(event):
    if event.sender_id not in unlocked_commands or not unlocked_commands[event.sender_id]:
        await event.reply("Команда не разблокирована! Введите /secret [пароль] для доступа.")
        return

    await event.respond("щащащаща")

    async with client.conversation("@ferganteusbot") as conv:
        try: 
            lh = await conv.send_message("/lh")
        except Exception as e:
            return await event.respond("Инвалид, разблокируй @Ferganteusbot")

        otvet = await conv.get_response()
        await lh.delete()

        if otvet.photo:
            await event.client.send_message(event.peer_id, message=otvet, reply_to=getattr(event, "reply_to_msg_id", None))
            await otvet.delete()
            await event.delete()

# Разблокировка команд
@client.on(events.NewMessage(pattern='/secret'))
async def secret_handler(event):
    code = event.raw_text.split(" ")[1] if len(event.raw_text.split(" ")) > 1 else ""

    if code == SECRET_CODE:
        unlocked_commands[event.sender_id] = True
        await event.reply("Теперь ты можешь юзать .loli")
    else:
        await event.reply("Неправильный код, попробуй снова.")

# Команда помощи
@client.on(events.NewMessage(pattern=f'[{"".join(prefixes)}]help'))
async def help_handler(event):
    help_text = """🔮 UGCLAWS USERBOT Lite 🔮

Доступные команды:
• .help - показать это сообщение
• .anime [nsfw] - случайное аниме фото
• .im [режим] - запустить имитацию (режимы: typing/voice/video/game/mixed)
• .imstop - остановить имитацию
• .time - включить/выключить время в нике
• .time_msk - установить московское время
• .time_ekb - установить екатеринбургское время 
• .time_omsk - установить омское время
• .time_samara - установить самарское время
• .hh <задержка> [текст] - отправлять спам-сообщения с указанной задержкой
• .del <количество> - удалить указанное количество своих сообщений
• .ping - проверить скорость ответа бота
• .info - показать информацию о боте с фото"""

    if event.sender_id in unlocked_commands and unlocked_commands[event.sender_id]:
        help_text += "\n• .loli - случайная лоли фотография"

    await event.edit(help_text)

# Команда для отправки аниме фото
@client.on(events.NewMessage(pattern=f'[{"".join(prefixes)}]anime'))
async def anime_handler(event):
    args = event.raw_text.split()
    if len(args) > 1 and args[1].lower() == "nsfw":
        url = "https://api.waifu.pics/nsfw/waifu"
        caption = "🎗 Лови NSFW фото!"
    else:
        url = "https://api.waifu.pics/sfw/waifu"
        caption = "🔮 Случайное аниме фото!"

    message = await event.respond("ван сек..")

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    if "url" in data:
                        await event.client.send_file(event.chat_id, data["url"], caption=caption)
                        await message.delete()
                    else:
                        await message.edit("Ошибка: не удалось найти URL в ответе.")
                else:
                    await message.edit(f"Ошибка: {response.status}")
    except Exception as e:
        await message.edit(f"Ошибка: {e}")

# Имитация активности
@client.on(events.NewMessage(pattern=f'[{"".join(prefixes)}]im'))
async def im_handler(event):
    args = event.raw_text.split()[1] if len(event.raw_text.split()) > 1 else "mixed"
    mode = args.lower()
    chat_id = event.chat_id

    if chat_id in _imitation_active and _imitation_active[chat_id]:
        await event.edit("❌ Имитация уже запущена")
        return

    _imitation_active[chat_id] = True
    _imitation_tasks[chat_id] = asyncio.create_task(_imitate(event.client, chat_id, mode))

    await event.edit(f"🎭 Имитация запущена\nРежим: {mode}")

_imitation_tasks = {}
_imitation_active = {}

async def _imitate(client, chat_id, mode):
    try:
        while _imitation_active.get(chat_id, False):
            async with client.action(chat_id, mode):
                await asyncio.sleep(5)
    except Exception as e:
        logger.error(f"Ошибка имитации: {e}")
        _imitation_active[chat_id] = False

@client.on(events.NewMessage(pattern=f'[{"".join(prefixes)}]imstop'))
async def imstop_handler(event):
    chat_id = event.chat_id
    _imitation_active[chat_id] = False
    if chat_id in _imitation_tasks:
        _imitation_tasks[chat_id].cancel()
        del _imitation_tasks[chat_id]

    await event.edit("🚫 Имитация остановлена")

# Время в нике
_time_running = False
_time_timezone = 'Europe/Moscow'

@client.on(events.NewMessage(pattern=f'[{"".join(prefixes)}]time'))
async def time_handler(event):
    global _time_running
    _time_running = not _time_running
    await event.edit("📡Обновление времени в нике " + ("🔌включено" if _time_running else "🔌выключено"))
    if _time_running:
        asyncio.create_task(update_nick(event.client))

async def update_nick(client):
    global _time_running, _time_timezone
    while _time_running:
        tz = pytz.timezone(_time_timezone)
        current_time = datetime.now(tz).strftime("%H:%M")

        me = await client.get_me()
        current_nick = me.first_name.split("|")[0].strip()
        new_nick = f"{current_nick} | {current_time}"

        try:
            await client(UpdateProfileRequest(first_name=new_nick))
        except Exception as e:
            print(f"Ошибка обновления ника: {e}")

        await asyncio.sleep(60)

@client.on(events.NewMessage(pattern=f'[{"".join(prefixes)}]time_msk'))
async def time_msk_handler(event):
    global _time_timezone
    _time_timezone = 'Europe/Moscow'
    await event.edit("Часовой пояс: Москва")

@client.on(events.NewMessage(pattern=f'[{"".join(prefixes)}]time_ekb'))
async def time_ekb_handler(event):
    global _time_timezone
    _time_timezone = 'Asia/Yekaterinburg'
    await event.edit("Часовой пояс: Екатеринбург")

# Глобальная переменная для отслеживания статуса спама
_hh_active = {}

# Команда hh для спам-сообщений с задержкой
@client.on(events.NewMessage(pattern=f'[{"".join(prefixes)}]hh'))
async def hh_handler(event):
    chat_id = event.chat_id
    
    # Простая .hh без аргументов отключает спам
    args = event.raw_text.split(' ', 1)
    if len(args) < 2:
        if chat_id in _hh_active and _hh_active[chat_id]:
            _hh_active[chat_id] = False
            await event.edit("f")
        else:
            await event.edit("Использование: .hh <задержка в сек> [текст]")
        return  # Добавляем return, чтобы прервать выполнение функции

    # Проверяем, есть ли хотя бы задержка
    parts = args[1].split(' ', 1)
    if not parts[0].isdigit():
        await event.edit("Использование: .hh <задержка в сек> [текст]")
        return

    time_delay = int(parts[0])
    # Если текст не указан, используем пустую строку
    text = parts[1] if len(parts) > 1 else ""

    # Остановить предыдущий спам, если был
    _hh_active[chat_id] = False
    await asyncio.sleep(0.5)  # Небольшая пауза для остановки предыдущего цикла
    
    await event.edit("на изи тебя отьебу\n\n")

    shabl = [" мамашу твою ебал сынок шлюхи ты хехе ", " поимел тебя сынка шлюхи ебаного прикинь ",
             " твою мать в рот ебал", " пососал ты сынок шлюхи ", " ты мне жестко отсосал щас или че хуесаска лалка ",
             " блять вот у тебя мамаша шлюха ебучая ", " вот твою мамашу ебали а ты даж ниче не сказал лошок ",
             " пиздец соси ", "усоси", " засоси", " пососи", " соси мне блядина ", " отсоси, сынок шлюхи ",
             " спермоглист, ебучку втопи ", " пахай на моем члене, раб", " насоси хуйца", " хуй лови ", " яйца на ",
             " хуй на ", " я тебе свой хуй кинул как фрисби", " пес ебаный ты нахуй отсосал", " лох ебаный ты че потух опять ",
             " сдавил тя залупой хе"," хуй жри", " слабак че спишь ", " засоси", " обсоси", " сасай шкура"]

    # Запускаем новый спам
    _hh_active[chat_id] = True
    
    while _hh_active.get(chat_id, False):
        try:
            await event.respond(text + (random.choice(shabl)))
            await asyncio.sleep(time_delay)
        except Exception as e:
            _hh_active[chat_id] = False
            await event.respond(f"Ошибка: {e}")

# Команда для удаления своих сообщений
@client.on(events.NewMessage(pattern=f'[{"".join(prefixes)}]del'))
async def del_handler(event):
    args = event.raw_text.split()

    if len(args) != 2 or not args[1].isdigit():
        await event.edit("Использование: .del <количество>")
        return

    count = int(args[1])

    # Получаем сообщения из чата
    messages = []
    async for msg in client.iter_messages(event.chat_id, from_user='me', limit=count+1):
        messages.append(msg.id)

    # Удаляем сообщения
    await client.delete_messages(event.chat_id, messages)

    # Отправляем сообщение о результате
    result_msg = await event.respond(f"✅ Удалено {len(messages)-1} сообщений.")
    await asyncio.sleep(3)
    await result_msg.delete()

# Команда для проверки пинга
@client.on(events.NewMessage(pattern=f'[{"".join(prefixes)}]ping'))
async def ping_handler(event):
    start = time.time()
    await event.edit("Проверка пинга...")
    end = time.time()
    ping_time = round((end - start) * 1000, 2)
    
    await event.edit(f"🏓 Понг!\nСкорость ответа: {ping_time} мс")


# Команда для информации о боте
@client.on(events.NewMessage(pattern=f'[{"".join(prefixes)}]info'))
async def info_handler(event):
    photo_url = "https://i.postimg.cc/bwmNM1Nr/Picsart-25-03-04-18-12-10-029.jpg"
    caption = "🔮 UGCLAWS USERBOT Lite 🔮\n\nTelegram channel: @ugclaws_tg\nИспользуйте .help для просмотра всех доступных команд."
    
    try:
        # Удаляем сообщение с командой
        await event.delete()
        # Отправляем новое сообщение с фото и текстом о боте
        await event.client.send_file(
            event.chat_id,
            photo_url,
            caption=caption
        )
    except Exception as e:
        # В случае ошибки отправляем только текстовое сообщение
        await event.respond(f"🔮 UGCLAWS USERBOT Lite 🔮\n\nЭто бот для Telegram.\nОшибка при загрузке фото: {str(e)}")

# Автоматическое удаление команд
@client.on(events.NewMessage(outgoing=True))
async def auto_delete_commands(event):
    if event.message.text:
        for prefix in prefixes:
            # Проверяем только команды loli и anime
            if (event.message.text.startswith(f"{prefix}loli") or 
                event.message.text.startswith(f"{prefix}anime")):
                await asyncio.sleep(0.5)  # Небольшая задержка
                await event.message.delete()
                break

# Запуск бота
# Функция для безопасного запуска бота
async def safe_start():
    try:
        # Подключаемся без полной инициализации сразу
        await client.connect()
        print("Соединение установлено...")

        # Пауза после соединения перед полной инициализацией
        await asyncio.sleep(5)

        # Проверка авторизации
        if not await client.is_user_authorized():
            print("Требуется авторизация! Запрашиваем код...")
            await client.send_code_request(phone)
            code = input("Введите код из Telegram: ")
            try:
                await client.sign_in(phone, code)
            except Exception as e:
                if "Two-steps verification" in str(e):
                    password = input("Введите пароль двухфакторной аутентификации: ")
                    await client.sign_in(password=password)
                else:
                    raise

        # Еще одна пауза перед началом работы
        print("Ожидание стабилизации соединения...")
        await asyncio.sleep(10)

        return True
    except Exception as e:
        print(f"Ошибка при подключении: {e}")
        return False

async def main():
    # Безопасный запуск с повторными попытками
    connected = False
    max_attempts = 3
    attempt = 0

    while not connected and attempt < max_attempts:
        attempt += 1
        print(f"Попытка подключения {attempt}/{max_attempts}...")
        connected = await safe_start()

        if not connected:
            wait_time = 30 * attempt  # увеличиваем время ожидания с каждой попыткой
            print(f"Подключение не удалось. Ожидание {wait_time} секунд перед повторной попыткой...")
            await asyncio.sleep(wait_time)

    if connected:
        print("Бот успешно запущен!")

        # Первое подключение - минимальная активность
        await asyncio.sleep(30)  # Ждем 30 секунд без активности

        # Запускаем основной цикл работы бота
        await client.run_until_disconnected()
    else:
        print("Не удалось подключиться после нескольких попыток. Пожалуйста, проверьте интернет-соединение и API-данные.")

if __name__ == '__main__':
    # Глобальный обработчик исключений
    phone = input("Введите номер телефона (с кодом страны): ") if "phone" not in config else config.get("phone")

    # Сохраняем телефон в конфиг, если его там нет
    if "phone" not in config:
        config["phone"] = phone
        save_config(config)

    while True:
        try:
            asyncio.run(main())
        except KeyboardInterrupt:
            print("Бот остановлен пользователем")
            break
        except Exception as e:
            print(f"Критическая ошибка: {e}")
            print("Перезапуск через 60 секунд...")
            time.sleep(60)